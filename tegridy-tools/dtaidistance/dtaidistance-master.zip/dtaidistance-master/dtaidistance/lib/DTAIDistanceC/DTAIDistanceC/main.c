//
//  main.c
//  DTAIDistance
//
//  Created by Wannes Meert on 26/06/2020.
//  Copyright © 2020 Wannes Meert. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    return 0;
}
