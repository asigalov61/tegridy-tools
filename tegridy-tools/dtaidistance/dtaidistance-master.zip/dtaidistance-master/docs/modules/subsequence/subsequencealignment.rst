
.. automodule:: dtaidistance.subsequence.subsequencealignment
   :members:
   :undoc-members:
   :inherited-members:
