# einops.pack and einops.unpack

## einops.pack

::: einops.pack

<br />

## einops.unpack

::: einops.unpack