# einops.reduce

::: einops.reduce