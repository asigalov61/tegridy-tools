.. pychord documentation master file, created by
   sphinx-quickstart on Sat Dec 31 14:51:42 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pychord's documentation!
===================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   pychord


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
