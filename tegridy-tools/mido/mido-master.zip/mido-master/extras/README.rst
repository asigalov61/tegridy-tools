Disclaimer
===========

These are experimental versions of functionality that may be rolled
into Mido some time in the future. Until the, proceed at your own
risk. (Where risk means the danger the code will crash or that the API
will change once you had just gotten used to it.)
