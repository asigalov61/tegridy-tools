# einops.einsum

::: einops.einsum