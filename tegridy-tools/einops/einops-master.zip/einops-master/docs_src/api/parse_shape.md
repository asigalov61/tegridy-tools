# einops.parse_shape

::: einops.parse_shape