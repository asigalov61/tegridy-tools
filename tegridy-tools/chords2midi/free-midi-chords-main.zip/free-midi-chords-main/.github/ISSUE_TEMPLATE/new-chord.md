---
name: new chord
about: Suggest new chord progressions
title: "[new chord progression] "
labels: new chords
assignees: ''

---

** Which Chord progression would you like to add to the pack? **

I-V-iv-VI
