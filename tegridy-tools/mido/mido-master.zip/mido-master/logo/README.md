# The Mido Logo

The logo for Mido is two DIN (MIDI) connectors in the colors and position of
the snakes in the Python logo.

It was based on a trace of a DIN connector diagram and needs a bit of cleanup.

I've included a PNG render that we can use for now as a GitHub icon.

- Ole Martin
