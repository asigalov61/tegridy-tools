
.. automodule:: dtaidistance.clustering.kmeans
   :members:
   :undoc-members:
   :inherited-members:
