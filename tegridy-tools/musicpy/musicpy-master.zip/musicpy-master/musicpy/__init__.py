if __name__ == '__main__':
    from musicpy import *
else:
    from .musicpy import *
