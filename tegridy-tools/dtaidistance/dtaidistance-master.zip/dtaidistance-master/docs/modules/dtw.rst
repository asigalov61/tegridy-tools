
.. automodule:: dtaidistance.dtw
   :members:

.. autoclass:: dtaidistance.dtw.DTWSettings
   :members:
