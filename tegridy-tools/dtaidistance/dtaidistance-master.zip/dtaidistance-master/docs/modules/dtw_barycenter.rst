
.. automodule:: dtaidistance.dtw_barycenter
   :members:
