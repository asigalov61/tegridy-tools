
.. automodule:: dtaidistance.clustering.medoids
   :members:
   :undoc-members:
   :inherited-members:
