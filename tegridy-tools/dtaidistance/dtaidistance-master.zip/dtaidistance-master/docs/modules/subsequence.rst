
subsequence
~~~~~~~~~~~

.. toctree::
   :caption: Subsequence

   subsequence/subsequencesearch
   subsequence/subsequencealignment
   subsequence/localconcurrences
