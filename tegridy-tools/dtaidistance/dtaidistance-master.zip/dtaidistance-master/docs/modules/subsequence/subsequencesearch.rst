
.. automodule:: dtaidistance.subsequence.subsequencesearch
   :members:
   :undoc-members:
   :inherited-members:
