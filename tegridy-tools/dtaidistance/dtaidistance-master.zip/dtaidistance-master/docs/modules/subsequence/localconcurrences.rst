
.. automodule:: dtaidistance.subsequence.localconcurrences
   :members:
   :undoc-members:
   :inherited-members:
