
.. automodule:: dtaidistance.dtw_ndim
   :members:
