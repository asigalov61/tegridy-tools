
clustering
~~~~~~~~~~

.. toctree::
   :caption: Clustering

   clustering/hierarchical
   clustering/kmeans
   clustering/medoids
